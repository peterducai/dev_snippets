#!/bin/bash
git submodule update --init --recursive
git submodule update --remote